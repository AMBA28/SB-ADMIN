﻿using System;
using System.Collections.Generic;

namespace LIMs.UserInterface.Contexts
{
    public partial class Specimen
    {
        public long SpecimenID { get; set; }
        public string SpesCode { get; set; }
        public string Typename { get; set; }
        public long? CreateDateID { get; set; }
        public DateTime? CreateDate { get; set; }
        public long? LastUpdateID { get; set; }
        public DateTime? LastUpdateDate { get; set; }
    }
}