﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace LIMs.UserInterface.Contexts.Lists
{
    public class spEmployeeList
    {
        public string Fullname { get; set; }

        [Key]
        public long EmployeeID { get; set; }

        public string Lastname { get; set; }
        public string Firstname { get; set; }
        public string Middlename { get; set; }
        public string Title { get; set; }
        public string Position { get; set; }
        public string status { get; set; }
        public string Signature { get; set; }
        public long? CreateId { get; set; }
        public DateTime? Createdate { get; set; }
        public long? LastUpdateId { get; set; }
        public DateTime? LastUpdateDate { get; set; }
    }


}