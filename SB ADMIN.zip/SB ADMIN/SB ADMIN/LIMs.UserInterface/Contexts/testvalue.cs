﻿using System;
using System.Collections.Generic;

namespace LIMs.UserInterface.Contexts
{
    public partial class testvalue
    {
        public long ValuesID { get; set; }
        public string Catname { get; set; }
        public string Testname { get; set; }
        public string Gender { get; set; }
        public int? Age { get; set; }
        public string Normalvalues { get; set; }
        public string SInormal { get; set; }
        public long? CreateId { get; set; }
        public DateTime? CreateDate { get; set; }
        public long? LastupdateId { get; set; }
        public DateTime? LastupdateDate { get; set; }
    }
}