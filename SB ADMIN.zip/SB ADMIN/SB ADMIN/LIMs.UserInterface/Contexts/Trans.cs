﻿using System;
using System.Collections.Generic;

namespace LIMs.UserInterface.Contexts
{
    public partial class Trans
    {
        public long TransID { get; set; }
        public string patienceCreate { get; set; }
        public string dateofvisit { get; set; }
        public string physician { get; set; }
        public string test { get; set; }
        public string technologist { get; set; }
        public string ORnum { get; set; }
        public long? CreateID { get; set; }
        public DateTime? CreateDate { get; set; }
        public long? LastUpdateID { get; set; }
        public DateTime? LastUpdateDate { get; set; }
    }
}