﻿using System;
using System.Collections.Generic;

namespace LIMs.UserInterface.Contexts
{
    public partial class LabTestResultDetail
    {
        public long TestResultDetailId { get; set; }
        public long? TestResultHeaderId { get; set; }
        public short? DetailNo { get; set; }
        public int? TestId { get; set; }
        public short? Levels { get; set; }
        public string LabResult { get; set; }
        public string SILabResult { get; set; }
        public string Remarks { get; set; }
        public long? CreateId { get; set; }
        public DateTime? CreateDt { get; set; }
        public long? LastUpdateId { get; set; }
        public DateTime? LastUpdateDt { get; set; }
    }
}