﻿using System;
using System.Collections.Generic;

namespace LIMs.UserInterface.Contexts
{
    public partial class LabTest
    {
        public long LabID { get; set; }
        public string CategoryCode { get; set; }
        public string TestCode { get; set; }
        public string TestName { get; set; }
        public string TestTypes { get; set; }
        public long? CreateID { get; set; }
        public DateTime? CreateDate { get; set; }
        public long? LastUpdateID { get; set; }
        public DateTime? LastUpdateDate { get; set; }
    }
}