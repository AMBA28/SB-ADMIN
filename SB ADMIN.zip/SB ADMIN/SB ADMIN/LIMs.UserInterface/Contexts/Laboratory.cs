﻿using System;
using System.Collections.Generic;

namespace LIMs.UserInterface.Contexts
{
    public partial class Laboratory
    {
        public long LabID { get; set; }
        public string CatCode { get; set; }
        public string CatName { get; set; }
        public string CatDescription { get; set; }
        public long? CreateId { get; set; }
        public DateTime? CreateDate { get; set; }
        public long? LastUpdateId { get; set; }
        public DateTime? LastUpdateDate { get; set; }
    }
}