﻿using LIMs.UserInterface.Contexts.Lists;
using Microsoft.EntityFrameworkCore;

namespace LIMs.UserInterface.Contexts
{
    public partial class LimsContextList : DbContext
    {
       
        public LimsContextList()
        {
        }

        public LimsContextList(DbContextOptions<LimsContextList> options)
            : base(options)
        {
        }

        public virtual DbSet<spPatientList> spPatientList { get; set; }
        public virtual DbSet<spEmployeeList> SpEmployeeList { get; set; }
    }
}