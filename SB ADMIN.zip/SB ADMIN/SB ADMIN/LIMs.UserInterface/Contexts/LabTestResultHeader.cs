﻿using System;
using System.Collections.Generic;

namespace LIMs.UserInterface.Contexts
{
    public partial class LabTestResultHeader
    {
        public long TestResultHeaderId { get; set; }
        public short CategoryID { get; set; }
        public string ReferenceNo { get; set; }
        public long? PatientId { get; set; }
        public DateTime? TestDate { get; set; }
        public DateTime? ReceiveDate { get; set; }
        public short? Status { get; set; }
        public string Physician { get; set; }
        public string ReferringLab { get; set; }
        public string SpecimenType { get; set; }
        public long? PathologistId { get; set; }
        public short? PatientAge { get; set; }
        public string ORNo { get; set; }
        public long? CreateId { get; set; }
        public DateTime? CreateDt { get; set; }
        public long? LastUpdateId { get; set; }
        public DateTime? LastUpdateDt { get; set; }
        public long? ApproveId { get; set; }
        public DateTime? ApproveDt { get; set; }
        public long? CancelId { get; set; }
        public DateTime? CancelDt { get; set; }
        public long? VerifiedId { get; set; }
        public DateTime? VerifiedDt { get; set; }
    }
}