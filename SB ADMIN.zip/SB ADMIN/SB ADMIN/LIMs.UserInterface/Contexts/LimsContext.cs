﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace LIMs.UserInterface.Contexts
{
    public partial class LimsContext : DbContext
    {
        public LimsContext()
        {
        }

        public LimsContext(DbContextOptions<LimsContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Employee> Employee { get; set; }
        public virtual DbSet<LabTest> LabTest { get; set; }
        public virtual DbSet<LabTestResultDetail> LabTestResultDetail { get; set; }
        public virtual DbSet<LabTestResultHeader> LabTestResultHeader { get; set; }
        public virtual DbSet<Laboratory> Laboratory { get; set; }
        public virtual DbSet<Patient> Patient { get; set; }
        public virtual DbSet<Specimen> Specimen { get; set; }
        public virtual DbSet<Trans> Trans { get; set; }
        public virtual DbSet<testvalue> testvalue { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source=.\\SQLDEVELOPER2017;Initial Catalog=LimsDB;Persist Security Info=True;User ID=sa;Password=P@ssw0rd");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.0-rtm-35687");

            modelBuilder.Entity<Employee>(entity =>
            {
                entity.Property(e => e.Createdate).HasColumnType("date");

                entity.Property(e => e.Firstname)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdateDate).HasColumnType("date");

                entity.Property(e => e.Lastname)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Middlename)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Position)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Signature)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Title)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.status)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LabTest>(entity =>
            {
                entity.HasKey(e => e.LabID);

                entity.Property(e => e.CategoryCode)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CreateDate).HasColumnType("date");

                entity.Property(e => e.LastUpdateDate).HasColumnType("date");

                entity.Property(e => e.TestCode)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TestName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TestTypes)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LabTestResultDetail>(entity =>
            {
                entity.HasKey(e => e.TestResultDetailId);

                entity.Property(e => e.CreateDt).HasColumnType("datetime");

                entity.Property(e => e.LabResult)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdateDt).HasColumnType("datetime");

                entity.Property(e => e.Remarks)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.SILabResult)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LabTestResultHeader>(entity =>
            {
                entity.HasKey(e => e.TestResultHeaderId);

                entity.Property(e => e.ApproveDt).HasColumnType("datetime");

                entity.Property(e => e.CancelDt).HasColumnType("datetime");

                entity.Property(e => e.CreateDt).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDt).HasColumnType("datetime");

                entity.Property(e => e.ORNo)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Physician)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ReceiveDate).HasColumnType("datetime");

                entity.Property(e => e.ReferenceNo)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.ReferringLab)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.SpecimenType)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.TestDate).HasColumnType("datetime");

                entity.Property(e => e.VerifiedDt).HasColumnType("datetime");
            });

            modelBuilder.Entity<Laboratory>(entity =>
            {
                entity.HasKey(e => e.LabID);

                entity.Property(e => e.CatCode)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CatDescription)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.CatName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CreateDate).HasColumnType("date");

                entity.Property(e => e.LastUpdateDate).HasColumnType("date");
            });

            modelBuilder.Entity<Patient>(entity =>
            {
                entity.Property(e => e.Address)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Age)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Birthdate).HasColumnType("date");

                entity.Property(e => e.City)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Country)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CreateDate).HasColumnType("date");

                entity.Property(e => e.Email)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FirstName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Gender)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.HomePhoneNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdateDate).HasColumnType("date");

                entity.Property(e => e.MiddleName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MobileNumber)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Status)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Specimen>(entity =>
            {
                entity.Property(e => e.CreateDate).HasColumnType("date");

                entity.Property(e => e.LastUpdateDate).HasColumnType("date");

                entity.Property(e => e.SpesCode)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Typename)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Trans>(entity =>
            {
                entity.Property(e => e.CreateDate).HasColumnType("date");

                entity.Property(e => e.LastUpdateDate).HasColumnType("date");

                entity.Property(e => e.ORnum)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.dateofvisit)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.patienceCreate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.physician)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.technologist)
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.Property(e => e.test)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<testvalue>(entity =>
            {
                entity.HasKey(e => e.ValuesID);

                entity.Property(e => e.Catname)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CreateDate).HasColumnType("date");

                entity.Property(e => e.Gender)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastupdateDate).HasColumnType("date");

                entity.Property(e => e.Normalvalues)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.SInormal)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Testname)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}