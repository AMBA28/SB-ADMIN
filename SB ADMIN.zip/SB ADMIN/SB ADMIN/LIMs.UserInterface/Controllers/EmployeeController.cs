﻿using LIMs.UserInterface.Contexts;
using LIMs.UserInterface.Contexts.Lists;
using LIMs.UserInterface.Contracts;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace LIMs.UserInterface.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly IEmployeeService employeeService_;

        public object OrdersDetails { get; private set; }

        public EmployeeController(IEmployeeService employeeService)
        {
            employeeService_ = employeeService;
        }

        public async Task<IActionResult> Index()
        {
            ViewBag.DataSource = await employeeService_.GetEmployeeList();
            return View("../Patient/EmployeeIndex");
        }

        public async Task<IActionResult> Saveemployee(Employee model)
        {
            await employeeService_.Save(model);
            return Json(new { result = true });
        }

        public async Task<IActionResult> Employeeadd()
        {
            ViewBag.DataSource = await employeeService_.GetEmployeeList();
            return View("../Patient/AddEmployee");
        }

        [Route("Patient/EditEmployee/{EmployeeID}")]
        public async Task<IActionResult> EditEmployee(long EmployeeID)
        {
            var model = new Employee();
            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> ManageEmployee(Employee model, string action = "")
        {
            var isSuccess = true;
            var errMsg = string.Empty;
            var saveData = new Employee();
            try
            {
                saveData = await employeeService_.Saveemployee(model, action);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
                isSuccess = false;
            }

            return Json(new { result = isSuccess, model = saveData, errorMsg = errMsg });
        }
    }
}