﻿using LIMs.UserInterface.Contexts;
using LIMs.UserInterface.Contexts.Lists;
using LIMs.UserInterface.Contracts;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LIMs.UserInterface.Controllers
{
    public class PatientController : Controller
    {
        private readonly IPatientService patientService_;

        public object OrdersDetails { get; private set; }

        public PatientController(IPatientService patientService)
        {
            patientService_ = patientService;
        }

        public async Task<IActionResult> Index()
        {
            ViewBag.DataSource = await patientService_.GetPatientList();
            return View();
        }

        public async Task<IActionResult> Profile()
        {
            var model = new Patient();
            ViewBag.Country = await patientService_.InitForm(1);
            ViewBag.City = await patientService_.InitForm(2);
            return View(model);
        }

        public async Task<IActionResult> SavePatient(Patient model)
        {
            await patientService_.Save(model);
            return Json(new { result = true });
        }

        public async Task<IActionResult> Transaction(long PatientId = 0)
        {
            var model = new Patient();
            return View(model);
        }

        public async Task<IActionResult> EditProfile(long PatientId = 0)
        {
            var model = await patientService_.GetPatient(PatientId);
            return View("../Patient/EditProfile", model);
        }

        public class DataResult
        {
            public List<Patient> result { get; set; }
            public int count { get; set; }
        }

        public class ComboBoxObject
        {
            public int Id { get; set; }
            public string Value { get; set; }
        }

        [HttpPost]
        public async Task<IActionResult> ManagePatient(Patient model, string action = "")
        {
            var isSuccess = true;
            var errMsg = string.Empty;
            var saveData = new Patient();
            try
            {
                saveData = await patientService_.Savepatient(model, action);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
                isSuccess = false;
            }

            return Json(new { result = isSuccess, model = saveData, errorMsg = errMsg });
        }
        
        public async Task<IActionResult> LocationDetail()
        {

            ViewBag.Country = await patientService_.InitForm(1);
            ViewBag.City = await patientService_.InitForm(2);

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> InsertDefaultPatient(spPatientList model)
        {
            await patientService_.SaveDefaultPatient(model);
            return Json(new { result = true });
        }

    }
}
