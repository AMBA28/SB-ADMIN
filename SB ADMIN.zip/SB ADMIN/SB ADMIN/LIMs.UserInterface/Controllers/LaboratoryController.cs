﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LIMs.UserInterface.Contexts;
using LIMs.UserInterface.Contracts;
using Microsoft.AspNetCore.Mvc;

namespace LIMs.UserInterface.Controllers
{
    public class LaboratoryController : Controller
    {
        private readonly Contracts.ILaboratoryService LaboratoryService_;
       

        public object OrdersDetails { get; private set; }
        
        public LaboratoryController(ILaboratoryService LaboratoryService)
        {
            LaboratoryService_ = LaboratoryService;
        }
        //laboratory Category
        public async Task<IActionResult> Index()
        {
            //Get
            ViewBag.DataSource = await LaboratoryService_.GetLaboratoryList();
            return View("../Maintanace/LabTestCatergory");
        }

        public async Task<IActionResult> LabTestCatadd()
        {
            //Next Page
            ViewBag.DataSource = await LaboratoryService_.GetLaboratoryList();
            return View("../Maintanace/LabTestCatergoryAdd");
        }

        [HttpPost]
        public async Task<IActionResult> ManageLab(Laboratory model, string action = "")
        {
            //Update
            var isSuccess = true;
            var errMsg = string.Empty;
            var saveData = new Laboratory();
            try
            {
                saveData = await LaboratoryService_.SaveLab(model, action);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
                isSuccess = false;
            }

            return Json(new { result = isSuccess, model = saveData, errorMsg = errMsg });
        }

        public async Task<IActionResult> SaveLAb(Laboratory model)
        {
            //Save
            await LaboratoryService_.Save(model);
            return Json(new { result = true });
        }

    
        //Specimen
        public async Task<IActionResult> SpecimenList()
        {
            //Get
            ViewBag.DataSource = await LaboratoryService_.GetSpecimenList();
            return View("../Maintanace/SpecimenList");
        }
        public async Task<IActionResult> AddSpecimen()
        {
            //next page
            ViewBag.DataSource = await LaboratoryService_.GetSpecimenList();
            return View("../Maintanace/SpecimenAdd");
        }

        public async Task<IActionResult> SaveSpecimen(Specimen model)
        {
            //save
            await LaboratoryService_.Save(model);
            return Json(new { result = true });
        }

        [HttpPost]
        public async Task<IActionResult> ManageSpecimen(Specimen model, string action = "")
        {   
            //Update
            var isSuccess = true;
            var errMsg = string.Empty;
            var saveData = new Specimen();
            try
            {
                saveData = await LaboratoryService_.SaveSpecimen(model, action);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
                isSuccess = false;
            }

            return Json(new { result = isSuccess, model = saveData, errorMsg = errMsg });
        }


        //Normal Test Value
        public async Task<IActionResult> GetValue()
        {
            //Get
            ViewBag.DataSource = await LaboratoryService_.GetTestValueList();
            return View("../Maintanace/LabTestValue");
        }

        public async Task<IActionResult> LabTestValadd()
        {
            //Next Page
            ViewBag.DataSource = await LaboratoryService_.GetLaboratoryList();
            return View("../Maintanace/LabTestValueAdd");
        }

        [HttpPost]
        public async Task<IActionResult> ManageValue(testvalue model, string action = "")
        {
            //Update
            var isSuccess = true;
            var errMsg = string.Empty;
            var saveData = new testvalue();
            try
            {
                saveData = await LaboratoryService_.SaveValue(model, action);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
                isSuccess = false;
            }

            return Json(new { result = isSuccess, model = saveData, errorMsg = errMsg });
        }

        public async Task<IActionResult> SaveValues(testvalue model)
        {
            //Save
            await LaboratoryService_.Save(model);
            return Json(new { result = true });
        }


        //Laboratory Test
        public async Task<IActionResult> SaveLabList(LabTest model)
        {
            //Save
            await LaboratoryService_.Save(model);
            return Json(new { result = true });
        }

        public async Task<IActionResult> GetLabtest()
        {
            //Get
            ViewBag.DataSource = await LaboratoryService_.GetLaboratoryTest();
            return View("../Maintanace/LabTestList");
        }

        public async Task<IActionResult> LabTestadd()
        {
            //Next Page
            ViewBag.DataSource = await LaboratoryService_.GetLaboratoryTest();
            return View("../Maintanace/LabTestListAdd");
        }

        [HttpPost]
        public async Task<IActionResult> ManageLabTest(LabTest model, string action = "")
        {
            //Update
            var isSuccess = true;
            var errMsg = string.Empty;
            var saveData = new LabTest();
            try
            {
                saveData = await LaboratoryService_.SaveLabTest(model, action);
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
                isSuccess = false;
            }

            return Json(new { result = isSuccess, model = saveData, errorMsg = errMsg });
        }

        //Lab Trans
        public async Task<IActionResult> GetLabTestResulList(long PatientId)
        {
            //Next Page
            ViewBag.Physician = await LaboratoryService_.InitForm(1);
            ViewBag.Specimen = await LaboratoryService_.InitForm(2);

            ViewBag.Getlabresult = await LaboratoryService_.GetLabTestResultHeader(PatientId);
            return View("../Laboratory/LabMenu");
        }

        //public async Task<IActionResult> Getpatologiest(long EmployeeID)
        //{
        //    //Next Page
        //    ViewBag.GetlabPatologist = await LaboratoryService_.Getpatologiest(EmployeeID);
        //    return View("../Laboratory/LabMenu");
        //}


    }
}