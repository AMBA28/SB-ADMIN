﻿using LIMs.UserInterface.Contexts;
using LIMs.UserInterface.Contexts.Lists;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LIMs.UserInterface.Contracts
{
    public interface IEmployeeService
    {
        Task<int> Save(Employee model);

        Task<List<spEmployeeList>> GetEmployeeList();

        Task<Employee> Saveemployee(Employee model, string action = "");
       
    }
}