﻿using LIMs.UserInterface.Contexts;
using LIMs.UserInterface.Contexts.Lists;
using System.Collections.Generic;
using System.Threading.Tasks;
using static LIMs.UserInterface.Controllers.PatientController;

namespace LIMs.UserInterface.Contracts
{
    public interface IPatientService
    {
        Task<int> Save(Patient model);

        Task<List<spPatientList>> GetPatientList();

        Task<Patient> GetPatient(long PatientdId);

        Task<Patient> Savepatient(Patient model, string action = "");

        Task<List<ComboBoxObject>> InitForm(int option) ;

        Task<int> SaveDefaultPatient(spPatientList model);
    }
}
