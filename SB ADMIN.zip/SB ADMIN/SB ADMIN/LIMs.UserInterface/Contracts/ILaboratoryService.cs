﻿using LIMs.UserInterface.Contexts;
using LIMs.UserInterface.Contexts.Lists;
using System.Collections.Generic;
using System.Threading.Tasks;
using static LIMs.UserInterface.Controllers.PatientController;

namespace LIMs.UserInterface.Contracts
{
    public interface ILaboratoryService
    {
        //Laboratory Category
        Task<int> Save(Laboratory model);

        Task<List<Laboratory>> GetLaboratoryList();

        Task<Laboratory> SaveLab(Laboratory model, string action = "");


        //Normal Test Values
        Task<int> Save(testvalue model);

        Task<List<testvalue>> GetTestValueList();

        Task<testvalue> SaveValue(testvalue model, string action = "");
        
        
        //Specimen
        Task<int> Save(Specimen model);

        Task<List<Specimen>> GetSpecimenList();

        Task<Specimen> SaveSpecimen(Specimen model, string action = "");


        //Laboratory Test
        Task<int> Save(LabTest model);

        Task<List<LabTest>> GetLaboratoryTest();

        Task<LabTest> SaveLabTest(LabTest model, string action = "");


        //LabTransMenu
        Task<List<spPatientList>> GetLabTestResultHeader(long PatientId);

        //Task<List<spEmployeeList>> Getpatologiest(long EmployeeID);

        Task<List<ComboBoxObject>> InitForm(int option);
       
    }
}