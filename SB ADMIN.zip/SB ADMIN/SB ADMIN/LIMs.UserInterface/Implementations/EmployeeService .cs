﻿using LIMs.UserInterface.Contexts;
using LIMs.UserInterface.Contexts.Lists;
using LIMs.UserInterface.Contracts;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LIMs.UserInterface.Implementations
{
    public class EmployeeService : IEmployeeService
    {
        private readonly LimsContext context_;
        private readonly LimsContextList contextList_;

        public EmployeeService(LimsContext context,LimsContextList contextList)
        {
            context_ = context;
            contextList_ = contextList;
        }

        public async Task<List<spEmployeeList>> GetEmployeeList()
        {
            return await contextList_.SpEmployeeList
                .FromSql<spEmployeeList>("EXEC spEmployeeList").ToListAsync();
        }

        public async Task<int> Save(Employee model)
        {
            context_.Add(model);
            return await context_.SaveChangesAsync();
        }

        public async Task<int> SaveEmployee(spEmployeeList model)
        {

            if (model.EmployeeID == 0)
            {
                model.status = "Active";
                model.Createdate = DateTime.Now;
                context_.Add(model);
            }
            else
            {
                model.LastUpdateDate = DateTime.Now;
                context_.Update(model);
            }
            return await context_.SaveChangesAsync();

        }

        public async Task<Employee> Saveemployee(Employee model, string action = "")
        {
            if (action == "delete")
            {
                context_.Remove(model);
            }
            else
            {
                model.LastUpdateDate = DateTime.Now;
                context_.Update(model);
            }

            await context_.SaveChangesAsync();

            return model;
        }


    }
}