﻿using LIMs.UserInterface.Contexts;
using LIMs.UserInterface.Contexts.Lists;
using LIMs.UserInterface.Contracts;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using static LIMs.UserInterface.Controllers.PatientController;

namespace LIMs.UserInterface.Implementations
{
    public class LaboratoryService : ILaboratoryService
    {
        private readonly LimsContext context_;
        private readonly LimsContextList contextList_;

        public LimsContextList ContextList_ => contextList_;

        public LaboratoryService(LimsContext context, LimsContextList contextList)
        {
            context_ = context;
            contextList_ = contextList;
        }

        public async Task<List<Laboratory>> GetLaboratoryList()
        {
            //Get
            return await context_.Laboratory.ToListAsync();
        }

        public async Task<int> Save(Laboratory model)
        {
            //Save
            context_.Add(model);
            return await context_.SaveChangesAsync();
        }

        public async Task<Laboratory> SaveLab(Laboratory model, string action = "")
        {
            //Update
            if (action == "delete")
            {
                context_.Remove(model);
            }
            else
            {
                model.LastUpdateDate = DateTime.Now;
                context_.Update(model);
            }

            await context_.SaveChangesAsync();

            return model;
        }
        //Normal Test Value
        public async Task<List<testvalue>> GetTestValueList()
        {
            //Get
            return await context_.testvalue.ToListAsync();
        }

        public async Task<int> Save(testvalue model)
        {
            //Save
            context_.Add(model);
            return await context_.SaveChangesAsync();
        }

        public async Task<testvalue> SaveValue(testvalue model, string action = "")
        {
            //Update
            if (action == "delete")
            {
                context_.Remove(model);
            }
            else
            {
                model.LastupdateDate = DateTime.Now;
                context_.Update(model);
            }

            await context_.SaveChangesAsync();

            return model;
        }
        //Specimen
        public async Task<List<Specimen>> GetSpecimenList()
        {
            //Get
            return await context_.Specimen.ToListAsync();
        }

        public async Task<int> Save(Specimen model)
        {
            //Save
            context_.Add(model);
            return await context_.SaveChangesAsync();
        }

        public async Task<Specimen> SaveSpecimen(Specimen model, string action = "")
        {
            //Update
            if (action == "delete")
            {
                context_.Remove(model);
            }
            else
            {
                model.LastUpdateDate = DateTime.Now;
                context_.Update(model);
            }

            await context_.SaveChangesAsync();

            return model;
        }

            //Laboratory Test
            public async Task<List<LabTest>> GetLaboratoryTest()
            {   
                //Get
                return await context_.LabTest.ToListAsync();
            }

            public async Task<int> Save(LabTest model)
            {
                //save
                context_.Add(model);
                return await context_.SaveChangesAsync();
            }

            public async Task<LabTest> SaveLabTest(LabTest model, string action = "")
            {
                //Update
                if (action == "delete")
                {
                    context_.Remove(model);
                }
                else
                {
                    model.LastUpdateDate = DateTime.Now;
                    context_.Update(model);
                }

                await context_.SaveChangesAsync();

                return model;
            }

        //Lab Menu
       public async Task<List<spPatientList>> GetLabTestResultHeader(long PatientId)
       {
            //Get
            return await contextList_.spPatientList
            .FromSql<spPatientList>("EXEC spPatientList").ToListAsync();
       }

        //public async Task<List<spEmployeeList>> Getpatologiest(long EmployeeID)
        //{
        //    //Get
        //    return await contextList_.SpEmployeeList
        //    .FromSql<spEmployeeList>("EXEC spEmployeeList").ToListAsync();
        //}

        public async Task<List<ComboBoxObject>> InitForm(int option)
        {
            var retValue = new List<ComboBoxObject>();

            switch (option)
            {
                case 1:
                    retValue = new List<ComboBoxObject>
                    {
                        new ComboBoxObject { Id = 1, Value = "Fransic Done" },
                        new ComboBoxObject { Id = 2, Value = "Willy Ong" },
                        new ComboBoxObject { Id = 3, Value = "Vicky Velo" },
                        new ComboBoxObject { Id = 4, Value = "Heiden Co" }
                    };
                    break;
                case 2:
                    retValue = new List<ComboBoxObject>
                    {
                        new ComboBoxObject { Id = 1, Value = "Urine" },
                        new ComboBoxObject { Id = 2, Value = "CBC" },
                        new ComboBoxObject { Id = 3, Value = "Hematology" }
                    };
                    break;

                default:
                    break;
            }
            return retValue;
        }
    }
}