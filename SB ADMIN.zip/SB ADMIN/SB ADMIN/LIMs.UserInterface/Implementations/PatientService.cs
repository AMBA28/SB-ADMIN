﻿using LIMs.UserInterface.Contexts;
using LIMs.UserInterface.Contexts.Lists;
using LIMs.UserInterface.Contracts;
using LIMs.UserInterface.Controllers;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using static LIMs.UserInterface.Controllers.PatientController;

namespace LIMs.UserInterface.Implementations
{
    public class PatientService : IPatientService
    {
        private readonly LimsContext context_;
        private readonly LimsContextList contextList_;

        public PatientService(LimsContext context, LimsContextList contextList)
        {
            context_ = context;
            contextList_ = contextList;
        }

        public async Task<List<spPatientList>> GetPatientList()
        {
            return await contextList_.spPatientList
                .FromSql<spPatientList>("EXEC spPatientList").ToListAsync();
        }

        public async Task<int> Save(Patient model)
        {
            context_.Add(model);
            return await context_.SaveChangesAsync();
        }

        public async Task<Patient> GetPatient(long patiendId)
        {
            var result = await context_.Patient.FirstOrDefaultAsync(p => p.PatientId == patiendId);
            return (result == null) ? new Patient() : result;
        }

        public async Task<Patient> Savepatient(Patient model, string action = "")
        {
            if (action == "delete")
            {
                context_.Remove(model);//change to retrive
            }
            else
            {
                //var patient = await GetPatient(model.PatientId);
                //var bdate = (DateTime)patient.Birthdate;
                //var age = 0;

                //if (!string.IsNullOrEmpty(model.Age))
                //{
                //    age = Int32.Parse(model.Age);
                //    model.Birthdate = new DateTime((DateTime.Now.Year - age), bdate.Month, bdate.Day);
                //}

                model.LastUpdateDate = DateTime.Now;
                context_.Update(model);
            }

            await context_.SaveChangesAsync();

            return model;
        }

        public async Task<List<ComboBoxObject>> InitForm(int option)
        {
            var retValue = new List<ComboBoxObject>();

            switch (option)
            {
                case 1:
                    retValue = new List<ComboBoxObject>
                    {
                        new ComboBoxObject { Id = 1, Value = "Phillippines" }
                    };
                    break;
                case 2:
                    retValue = new List<ComboBoxObject>
                    {
                        new ComboBoxObject { Id = 1, Value = "Caloocan City" },
                        new ComboBoxObject { Id = 2, Value = "Las Piñas City" },
                        new ComboBoxObject { Id = 3, Value = "Makati City" },
                        new ComboBoxObject { Id = 4, Value = "Malabon City" },
                        new ComboBoxObject { Id = 5, Value = "Mandaluyong City" },
                        new ComboBoxObject { Id = 6, Value = "City of Manila" },
                        new ComboBoxObject { Id = 7, Value = "Marikina City" },
                        new ComboBoxObject { Id = 8, Value = "Muntinlupa City" },
                        new ComboBoxObject { Id = 9, Value = "Navotas City" },
                        new ComboBoxObject { Id = 10, Value = "Parañaque City" },
                        new ComboBoxObject { Id = 11, Value = "Pasay City" },
                        new ComboBoxObject { Id = 12, Value = "Pasig City" },
                        new ComboBoxObject { Id = 13, Value = "Pateros City" },
                        new ComboBoxObject { Id = 14, Value = "Quezon City" },
                        new ComboBoxObject { Id = 15, Value = "San Juan City" },
                        new ComboBoxObject { Id = 16, Value = "Taguig City" },
                        new ComboBoxObject { Id = 17, Value = "Valenzuela City" }
                    };
                    break;

                default:
                    break;
            }
            return retValue;
        }

        public async Task<int> SaveDefaultPatient(spPatientList model)
        {

            if (model.PatientId == 0)
            {
                model.CreateDate = DateTime.Now;
                context_.Add(model);
            }
            else
            {
                model.LastUpdateDate = DateTime.Now;
                context_.Update(model);
            }

            return await context_.SaveChangesAsync();
        }
    }
       
}