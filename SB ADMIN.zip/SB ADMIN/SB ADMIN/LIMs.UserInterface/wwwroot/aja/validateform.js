﻿var ValidateService = (function () {

    var validateEntry = function (formId) {

        var requiredClass = 'aja-validate-required';
        var hasErrors = 0;
        var form = document.getElementById(formId);

        for (var i = 0; i < form.elements.length; i++) {

            var elementId = form.elements[i].id;
            if (elementId === '') {
                continue;
            }

            var elementObject = $('#' + elementId);

            elementObject.next().remove('.diverror');
            elementObject.parent().next().remove('.diverror');

            if (form.elements[i].hasAttribute('req') | form.elements[i].hasAttribute('req-email')) {
                var errMsg = "";

                if (($.trim(form.elements[i].value) === '' || form.elements[i].value === "0") && form.elements[i].hasAttribute('req')) {
                    errMsg += "Field is required. ";

                    if (elementObject.hasClass('SumoUnder')) {
                        elementObject.parent().addClass(requiredClass);
                        elementObject.parent().after("<div class='diverror'>" + errMsg + "</div>");
                    }
                    else {
                        elementObject.addClass(requiredClass);
                        elementObject.after("<div class='diverror'>" + errMsg + "</div>");
                    }
                    hasErrors++;
                } else {
                    if (elementObject.hasClass('SumoUnder')) {
                        elementObject.parent().removeClass(requiredClass);
                        //$('#' + elementId).parent().nextUntil('.diverror').html("");
                    }
                    else {
                        elementObject.removeClass(requiredClass);
                        elementObject.next().remove('.diverror');
                    }
                }

                if (form.elements[i].hasAttribute('req-email')) {
                    if (!validateEmail($.trim(form.elements[i].value))) {
                        elementObject.after("<div class='diverror'>" + errMsg + "Invalid Email. </div>");
                        hasErrors++;
                    }
                }
            }
        }

        var pass = $("#" + formId).find('input[pwd]');
        var pass2 = $("#" + formId).find('input[pwd2]');

        pass.next().remove('.diverror');
        pass2.next().remove('.diverror');

        if (pass.val() !== pass2.val()) {
            pass.addClass(requiredClass);
            pass2.addClass(requiredClass);
            pass2.after("<div class='diverror'>Password mismatched!</div>");
            hasErrors++;
        }

        if (hasErrors > 0) { return false; }
        else { return true; }

    };

    var validateEmail = function (email) {
        var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
        if (!emailReg.test(email)) {
            return false;
        } else {
            return true;
        }
    };

    return {
        Form: {
            ValidateEntry: validateEntry,
        }
    };

})();