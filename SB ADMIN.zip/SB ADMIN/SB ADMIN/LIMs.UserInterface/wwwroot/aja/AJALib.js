﻿var AJALib = (function () {


    var saveRecord = function (fnSuccess) {
        $.confirm({
            title: 'Save changes!',
            content: 'Do you want to save changes?',
            type: 'green',
            typeAnimated: true,
            closeIcon: true,
            escapeKey: true,
            buttons: {
                confirmation: {
                    text: 'Yes',
                    btnClass: 'btn-green',
                    action: function () {
                        if (fnSuccess !== undefined) {
                            fnSuccess();
                        }
                    }
                },
                close: function () {
                }
            }
        });
    };

    var deleteRecord = function (fnSuccess) {
        $.confirm({
            title: 'Delete Record!',
            content: 'Are you sure you want to delete record?',
            type: 'red',
            typeAnimated: true,
            closeIcon: true,
            escapeKey: true,
            buttons: {
                confirmation: {
                    text: 'Yes',
                    btnClass: 'btn-red',
                    action: function () {
                        if (fnSuccess !== undefined)
                            fnSuccess();
                    }
                },
                close: function () {
                }
            }
        });
    };


    var confirmation = function (fnSuccess, title, message, progress) {
        $.confirm({
            title: title,
            content: message,
            type: 'green',
            typeAnimated: true,
            closeIcon: true,
            escapeKey: true,
            buttons: {
                confirmation: {
                    text: 'Yes',
                    btnClass: 'btn-success',
                    action: function () {

                        if (progress !== undefined)
                            $(progress).removeClass("hide");

                        if (fnSuccess !== undefined)
                            fnSuccess();
                    }
                },
                close: function () {
                }
            }
        });
    };



    var postAction = function (url, formData, fnSuccess, fnFailed) {
        $.ajax({
            url: url,
            type: 'POST',
            data: formData,
            success: function (data) {
                console.log(data);
                if (data['result'] !== undefined) {
                    retValue = data['result'];
                    if (retValue !== false) {
                        if (fnSuccess !== undefined) {
                            fnSuccess();
                        }
                    }
                    else {
                        if (fnFailed !== undefined) {
                            fnFailed();
                        }
                    }
                }
            }
        });
    };



    return {
        SaveRecord: saveRecord,
        DeleteRecord: deleteRecord,
        SubmitAction: postAction,
        Confirmation: confirmation


    };
})();